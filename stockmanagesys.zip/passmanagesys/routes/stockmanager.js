const express = require('express')
var router = express.Router()

router.get('/', (req, res, next)=>{
    console.log('Stock Manager')
    res.render('viewall', {title: "viewall", msg: ''})
})

module.exports = router