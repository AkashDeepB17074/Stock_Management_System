function deleteMe(){
    var errorBox = document.getElementsByClassName('error_box')[0]
    errorBox.remove()
    document.getElementsByClassName('limiter')[0].style.filter = "none";
}