const mongoose = require('mongoose')
var bcrypt = require('bcryptjs')

//  Connection Setttings
// const url = 'mongodb+srv://kingdeep:kingdeep238@kingdeepcluster-7sjxx.mongodb.net/stockmanagement?retryWrites=true&w=majority'
var url = 'mongodb://localhost:27017/stockmanagement?readPreference=primary&appname=MongoDB%20Compass&ssl=false'

mongoose.connect(url, {useNewUrlParser:1, useCreateIndex: true})

var db = mongoose.connection

db.on('error', console.error.bind(console, '## [{ CONNECTION ERROR }] ##'))
db.on('connected', ()=> console.log('## [{ CONNECTED }] ##'))
db.on('disconnected', ()=> console.log("## [{ DISCONNECTED }] ##"))


// Creating Schema 
var userSchema = new mongoose.Schema({
    typeOfUser: {
        type: String,
        enum: ['Admin',"Receptionist", "Store Manager"],
        require: true  
    },
    username: {
        type:String, 
        required: true, 
        index: {   
            unique: true
        }
    },
    email:{
        type: String, 
        required: true, 
        index:{
            unique: true
        }
    },
    password: {
        type:String, 
        required: true
    },
    date: {
        type: Date, 
        default: Date.now
    }
})

userSchema.methods.accountVerification = function(pass){
    console.log("user Schema", this.password, pass)
    if(bcrypt.compareSync(pass, this.password)){
        return true;
    }else{
        return false;
    }
}

var userModel = mongoose.model('usermanager', userSchema)


module.exports = userModel

