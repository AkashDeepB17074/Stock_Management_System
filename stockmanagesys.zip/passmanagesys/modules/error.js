function error_box(type, msg){
    var errorType = ['Success !', 'Info !', 'Warning !','Error !']
    var color = [{
            color: "#3c763d",
            background_color: "#dff0d8",
            border_color: "#d6e9c6"
        }, 
        {
            color: "#31708f",
            background_color: "#d9edf7",
            border_color: "#bce8f1"
        },
        {
            color: "#8a6d3b",
            background_color: "#fcf8e3",
            border_color: "#faebcc"

        },
        {
            color: "#a94442",
            background_color: "#f2dede",
            border_color: "#ebccd1"
        }]
    this.actionValue = "OK"
    this.type = errorType[type]
    this.msg = msg
    this.color = color[type]

    this.setActionValue = function(value){
        this.actionValue = value
    }

    this.setRedirectingPage = function(link, value){
        this.redirecting = link
        this.redirectingValue = value
    }

    this.setType = function(index){
        this.type = errorType[index]
        this.color = color[index]
    }
    
}

// let error = new error_box(1, "warning")
// let error2 = new error_box()
// // error2.msg = "hey ya"
// // error2.setType(1)
// // error2.setRedirectingPage('viewall')
// // console.log("error 1 =", error)
// if(error2.msg){
//     console.log('true')
// }else{
//     console.log('false')
// }
// console.log("error 2 =", error2)
// if(error2.redirecting) console.log("false") 
// else console.log('true')


module.exports = error_box;