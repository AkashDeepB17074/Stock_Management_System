var express = require('express');
var bcrypt = require('bcryptjs')
var jwt = require('jsonwebtoken')
var multer = require('multer')
var path = require('path')
const {check, validationResult} = require("express-validator")
var userModel = require('../modules/users')


if(typeof localStorage === "undefined" || localStorage == null){
  var LocalStorage = require('node-localstorage').LocalStorage
  localStorage = new LocalStorage('../scratch')
}


var router = express.Router();

/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Stock Manager', heading: "Stock Management System" });
});
console.log(__filename)


//  Sign Up things //
router.get('/signup', function(req, res, next){
  var loginUser = localStorage.getItem('loginUser')
  if(loginUser){
    res.redirect('/viewall')
  }else{
    res.render('signup', {title: "GET_Signup", msg: ''})
  }
})
var usernameValidation = function(req, res, next){
  var usr = req.body.username
  var checkExist = userModel.findOne({username: usr})
  checkExist.exec(function(err, data){
    if (err) throw err
    if (data)
    return res.render('signup', {title: "Validation", msg: 'username already exiet '})
    next()
  })
}

var emailValidation = function(req, res, next){
  var eid = req.body.email
  userModel.findOne({email: eid}, function(err, data){
    if (err) throw err
    if(data)
    return res.render('signup', {title:"Validation", msg: "Email id already Exists !"})
    next()
  })
}
// var userValidation = function(req, res, next){
//   var usr = req.body.username
//   var eid = req.body.email
//   let checkExistEmail = userModel.findOne({email: eid})
//   let checkExistUsername = userModel.findOne({username: usr})
//   let msg = {email: "", username: ""};
//   checkExistEmail.exec(function(err, data){
//     checkExistUsername.exec(function(err, data){
//       if (err) throw err
//       if(data){
//         msg.username = "Username Already Exists"
//       }
//     })
//     if (err) throw err;
//     if(data){
//       msg.email = "Email Already Exists"
//     }
//     if(msg.username !="" || msg.email!=""){
//       res.render('signup', {title:"Validation Signup", msg: msg})
//     }
//     next()
//   })
// }

router.post('/signup', usernameValidation, emailValidation,
            [check('email', 'Enter Valid Email Address').isEmail(), 
             check('password', 'Password Should Contain Atleast  char').isLength({min:5})],
            /*userValidation,
            [check('username', "Username should be of length > 1").isLength({min: 1}),
             check('email', "not a valid email id ").isEmail(), 
             check('password', "password must be greater than 8 digit").isLength({min:8})],*/
            function(req, res, next){
  console.log("############ SIGN UP POST #############")
  console.log(req.body)
  var tou = req.body.typeofuser
  var usrN = req.body.username
  var eid = req.body.email
  var pass = req.body.password
  var cpass = req.body.confirmpassword
  console.log('Condition Check' , usrN, eid, pass,((usrN == "") || (eid =="" || pass=="") ))
  
  const errors = validationResult(req);
  console.log('error mapped ==> ', errors.mapped())
  if(!errors.isEmpty()){
    msgs = ''
    if(errors.mapped().email)
      msgs = msgs + errors.mapped().email.msg 
    if(errors.mapped().password)
      msgs = msgs + errors.mapped().password 
    res.render('signup', {title:"emailPass Validator", msg:msgs})
  }
  else if((usrN == "") || (eid == "" || pass=="")){
    console.log('## [{ FILL ALL FIELDS }] ##')
    res.render('signup', {title: "fillfield", msg: "FIll All the field"})
  }
  else if(pass != cpass){
    console.log('## [{ PASSWORD NOT MATCHED }] ##')
    res.render('signup', {title:"PassMatch", msg:  "Password not Match"})
  }else{
  pass = bcrypt.hashSync(pass, 10);
  console.log("user Model => ",userModel)
  var user = new userModel({
    typeOfUser: tou,
    username: usrN, 
    email: eid, 
    password: pass
  })

  // console.log(user)
  user.save((err, data)=>{
    if(err) throw err
    console.log(data)
    console.log("## [{ SAVED! }] ##")
    // res.redirect('login')
    res.render('signup', {title: "POST_SIGNUP", msg: "Successfully Saved"})
  })
  }
})
///////////////////////////////////////////~

// ################### TOKEN STORAGE WHICH WILL BE VERIFIED IN EVERYPAGE ###########

router.get('/login', (req, res, next)=>{
   var loginUser = localStorage.getItem('loginUser')
   if(loginUser){
      res.redirect('/viewall')
    }else{
      console.log('Redirected to login get')
      res.render('login', {title: 'Login Form',  msg:"", heading:'Stock Manager'})
    }
})

router.post('/login', (req, res, next)=>{
  console.log("redirected to login post")
  var eid = req.body.email;
  var pass = req.body.password; 
  var tou = req.body.typeofuser
  console.log('email :: ', eid)
  console.log('userModel :: ', userModel)
  var checkUser = userModel.findOne({email: eid})
  checkUser.exec((err, data)=>{
    if (err) throw err
    console.log("data  :: ",  data)
    console.log("paaaaaas  :: ", pass)
    console.log("Acc veri :: ", data.accountVerification(pass))
    if(data.accountVerification(pass)){
      var token = jwt.sign({email: eid}, 'loginTokenOfEmail')
      localStorage.setItem('loginToken', token)
      localStorage.setItem('loginUser', eid)
      console.log('## [{ USER VEREFIED }] ##')
      res.redirect('/viewall')
    }else{
      res.render('login', {title: 'Login Form', heading:'Stock Manager', msg:"Unable to login"})
    }
  })
})
/////////////////////////////

function checkUserLoggedIn(req, res, next){
  var getToken = localStorage.getItem('loginToken')
  try{
    var decoded = jwt.verify(getToken, 'loginTokenOfEmail')
  }catch(err){
    console.log("## [{ USER VALIDATION FAILED }] ##")
    return res.redirect('login')
  }
  next()
}

router.get('/viewall', checkUserLoggedIn, function(req, res, next){
  let loginUserId = localStorage.getItem('loginUser')
  console.log('Redirecting to viewall get')
  res.render('viewall', {msg: "logged In successfully !"})
})

router.get('/logout', function(req, res, next){
  localStorage.removeItem('loginUser')
  localStorage.removeItem('loginToken')
  console.log('logged out from sessions')
  res.redirect('/login')
})





// ########## ADD AND EDIT PASS ##############//
router.get('/addnew', checkUserLoggedIn, function(req, res, next){
  console.log('Redirected To Add New Stock')
  res.render('addnew', {title: "AddNew Stock", msg:''})
})
router.get('/edit', checkUserLoggedIn, function(req, res, next){
  console.log('Redirected To Add New Stock')
  res.render('edit', {title: "edit Stock", msg:""})
})



var stockModel = require('../modules/stockschema')
// ###################### ADD AND EDIT POST METHODS ################################
// var multer = require('multer')
var Storage = multer.diskStorage({
  destination: '../public/candidate', 
  filename: (req, file, cb)=>{
    console.log("fileName saved as ==> ", file.fieldname+"_"+Date.now()+"_"+path.extname(file.originalname))
    cb(null, file.fieldname+"_"+Date.now()+"_"+path.extname(file.originalname))
  }
})
var upload = multer({
  storage: Storage
}).single('input_file')

router.post('/addnew', checkUserLoggedIn, upload, function(req, res, next){
  console.log("user added information ")
  console.log(req.body)
  console.log(req.file)
  imgPath = null
  if (req.file)
    imgPath = req.file.path
  console.log("consdition ==> ", (req.body.weblink==""||(req.body.password==""||req.body.email=="")))
  if( req.body.weblink==""||(req.body.password==""||req.body.email=="")){
    console.log("rendering addnew right now")
    res.render('addnew', {title:"AddNew", msg: "Fill Required fields"})
  }
  else{
  var stock = new stockModel({
    username: localStorage.getItem('loginUser'),
    imagePath: imgPath, 
    weblink: req.body.weblink,
    email: req.body.email,
    password: req.body.password,
    password_type: req.body.passwordtype,
    description: req.body.description
  })
  stock.save(function(err, data){
    if(err) throw err
    res.render('addnew', {title: "Addnew Saved!", msg: "Saved Successfully"})
  })}
})







module.exports = router;

